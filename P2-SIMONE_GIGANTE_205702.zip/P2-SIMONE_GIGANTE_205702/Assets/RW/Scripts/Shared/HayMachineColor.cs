public enum HayMachineColor
{
    Blue, Yellow, Red
}
