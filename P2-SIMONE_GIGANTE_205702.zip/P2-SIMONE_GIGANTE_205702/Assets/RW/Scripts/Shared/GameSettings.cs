public static class GameSettings
{
    public static HayMachineColor hayMachineColor = HayMachineColor.Blue;
}

